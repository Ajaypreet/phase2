function newtodo() {
    let ul = document.getElementById("todolistitems");
    let li = document.createElement("li");
    let para = document.createElement("p");
    let listtodo = document.getElementById("addingintodo").value;
    let newtodo = document.createTextNode(listtodo);
    let removetodo = document.createElement("button");
    removetodo.setAttribute("onclick", "deletelist()");
    removetodo.setAttribute("class", "removebutton");
    removetodo.innerHTML = "remove";
    let checkbox = document.createElement("input");
    checkbox.setAttribute("type", "checkbox");
    checkbox.setAttribute("id", "mychkbox");
    checkbox.setAttribute("onclick", "myFunction()");
    //checkbox.setAttribute("onchange", "")
    para.setAttribute("id", "newlist");
    para.innerHTML = listtodo;
    li.appendChild(checkbox);
    li.appendChild(para);
    li.appendChild(removetodo);
    document.getElementById("todolistitems").appendChild(li);
    document.getElementById("addingintodo").value = "";

    var audio = new Audio("http://reboot-me.com/ouch.mp3");
     checkbox = document.getElementById('mychkbox'),
        myFunction = function () {
            if (checkbox.checked) {
                audio.play();
            } 
            
            
        };
}

function deletelist() {
    let delwork = document.getElementsByClassName("removebutton");
    for (i = 0; i < (delwork.length); i++) {
        delwork[i].onclick = function () {
            let div = this.parentElement;
            div.style.display = "none";
        }
    }
}

function myFunction() {

    let checkBox = document.getElementById("mychkbox");
    let listItem = document.getElementById("newlist");
    for (j = 0; j < checkBox.length && j < listItem.length; j++) {
        if (checkBox[j].checked) {
            listItem[j].style.textDecoration = "line-through";
        } else {
            listItem[j].style.textDecoration = "none";
        }
    }
}